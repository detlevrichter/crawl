-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 03. Mai 2026 um 21:24
-- Server-Version: 10.11.14-MariaDB-0+deb12u2
-- PHP-Version: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `THKoeln_live`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`) VALUES
(1, 'Verwaltung', 'Verwaltung'),
(2, 'Lehrende', 'Lehrende'),
(3, 'Studierende', 'Studierende'),
(4, 'Default', 'Default');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `category_competency_type`
--

CREATE TABLE `category_competency_type` (
  `category_slug` varchar(255) NOT NULL,
  `competency_type_slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `category_competency_type`
--

INSERT INTO `category_competency_type` (`category_slug`, `competency_type_slug`) VALUES
('Default', 'Datenschutz'),
('Default', 'KI'),
('Lehrende', 'Datenschutz'),
('Lehrende', 'KI'),
('Lehrende', 'Kollaboration'),
('Lehrende', 'Lehre');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `competency_types`
--

CREATE TABLE `competency_types` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'float',
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `example` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `competency_types`
--

INSERT INTO `competency_types` (`id`, `slug`, `type`, `label`, `description`, `example`) VALUES
(1, 'Textverarbeitung', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Textverarbeitung ', 'Die Facette Textbearbeitung beschreibt die Kompetenz, digitale Textdokumente zu erstellen, zu strukturieren und zu formatieren. Sie umfasst das Anwenden von Layout-, Gliederungs- und Automatisierungsfunktionen (Absätze, \nFormatvorlagen, Seiten- und Abschnittswechsel, Serienbriefe, Querverweise, Inhaltsverzeichnisse) sowie das gemeinsame Nachverfolgen und Prüfen von Änderungen.\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3'),
(2, 'Praesentation', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Präsentation', 'Die Facette Präsentation umfasst die Kompetenz, digitale Folienpräsentationen zu entwerfen, zu gestalten und vorzutragen. Dazu gehören der sichere Umgang mit Layout- und Designvorlagen (Folienmaster), Sprechernotizen und \r\nReferentenansicht, das Einbinden und zeitliche Steuern von Medien und Animationen, das Gruppieren von Objekten sowie das Einrichten interaktiver Navigationen.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '1'),
(3, 'Tabellenkalkulation', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Tabellenkalkulation', 'Die Facette Tabellenkalkulation umfasst die Kompetenz, Daten in Tabellen zu erfassen, zweckgerecht zu formatieren und mithilfe von Zell- bzw. Bereichsbezügen, Formeln und Funktionen (z. B. SUMME, WENN) dynamisch \r\nauszuwerten. Dazu gehören das Anpassen von Zahlen-, Datums-, Text- und Währungsformaten, das Aus- und Einblenden von Spalten oder Zeilen, das Aktualisieren von Diagrammdaten.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0.7'),
(4, 'Kollaboration', 'float', 'Digitale Kommunikation und Zusammenarbeit: Allgemeine Kollaboration', 'Allgemeine Kollaboration mit digitalen Tools beschreibt die Fähigkeit, digitale Werkzeuge effektiv zur teamorientierten Zusammenarbeit einzusetzen. Dazu zählen u. a. der organisierte Informationsaustausch per E-Mail, die Nutzung \r\nvon Cloudsystemen und die gemeinsame Bearbeitung von Dateien mit verlässlicher Rechte- und Versionsverwaltung.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0'),
(5, 'Videokonferenzen', 'float', 'Digitale Kommunikation und Zusammenarbeit: Videokonferenzen', 'Videokonferenzen umfassen die kompetente Nutzung gängiger Konferenztools zur synchronen und asynchronen Zusammenarbeit. Dazu gehören der technische Umgang mit Ton, Bild, Bildschirmfreigabe und Moderationsfunktionen \r\nsowie die Kenntnis typischer Herausforderungen und ihrer Lösungen.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0.3'),
(6, 'Projektmanagement', 'float', 'Digitale Kommunikation und Zusammenarbeit: Projektmanagement', 'Projektmanagement-Tools unterstützen die strukturierte Planung, Steuerung und Dokumentation von Projekten in digitalen Arbeitsumgebungen. Kompetenzen in diesem Bereich umfassen u. a. Aufgabenverteilung, \nAblaufvisualisierung, Rechteverwaltung, Nachverfolgbarkeit von Änderungen und die Nutzung automatisierter Workflows.\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0'),
(7, 'Lehre', 'float', 'Wissensvermittlung mithilfe digitaler Werkzeuge: Digitale Lehre', 'Einsatz digitaler Technologien zur Gestaltung und Durchführung von Lehrveranstaltungen. Diese Facette wird nur für Lehrende erhoben.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0.7'),
(8, 'Lernmanagementsysteme', 'float', 'Wissensvermittlung mithilfe digitaler Werkzeuge: Lernmanagementsysteme', 'Kompetenter Umgang mit Lernplattformen wie Moodle oder ILIAS. Diese Facette wird nur für Studierende erhoben.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '1'),
(9, 'Recherche', 'float', 'Digitale Recherche und Informationsbewertung', 'Die Kompetenz „Digitale Recherche und Informationsbewertung umfasst die Fähigkeit, einen Informationsbedarf klar zu formulieren, um gezielt und systematisch nach relevanten Informationen und Daten in digitalen Umgebungen \r\nsuchen zu können. Dies beinhaltet die Anwendung effektiver Suchstrategien (z.B. die Verwendung von Operatoren und Filtern) und die Auswahl geeigneter Informationsquellen – etwa allgemeine Suchmaschinen oder fachspezifische Datenbanken. Darüber hinaus schließt die Kompetenz die kritische Bewertung der gefundenen Informationen hinsichtlich ihrer Qualität, Relevanz und Vertrauenswürdigkeit ein.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0.3'),
(10, 'Literaturverwaltungsprogramme', 'float', 'Digitale Recherche und Informationsbewertung: Literaturverwaltungsprogramme', 'Literaturverwaltungsprogramme unterstützen das strukturierte Sammeln, Organisieren und Zitieren wissenschaftlicher Quellen. Kompetenzen in diesem Bereich umfassen u. a. den Import und die Pflege von Literaturdaten, die \r\nIntegration in Textverarbeitungsprogramme sowie die automatisierte Erstellung und Anpassung von Literaturverzeichnissen.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0'),
(11, 'Datenschutz', 'float', 'Schutz von Daten im digitalen Raum', 'Diese Kompetenz umfasst das Verständnis und die Anwendung grundlegender Prinzipien und Maßnahmen zum Schutz digitaler Informationen und Systeme. Dies beinhaltet das Wissen darüber, wie persönlich identifizierbare \r\nInformationen sicher verarbeitet und weitergegeben werden können, sowie das Wissen um potenzielle Risiken und Bedrohungen und geeignete Maßnahmen zum Schutz von Daten und Endgeräten vor unbefugtem Zugriff, Missbrauch oder Beschädigung. Der Aspekt der Datenintegrität umfasst Kenntnisse und Strategien, um Daten vor Verlust zu schützen, etwa durch regelmäßige Backups oder die Nutzung sicherer Speicherlösungen.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '1'),
(12, 'KI', 'float', 'Künstliche Intelligenz', 'KI-Kompetenz umfasst die Fähigkeit, (generative) künstliche Intelligenz (KI) und deren Anwendungen zu nutzen und die Ergebnisse kritisch zu bewerten. Sie beinhaltet die Fähigkeit, effektiv mit KI zu kommunizieren, sowie Kenntnisse über grundlegende KI-Konzepte, Algorithmen und maschinelles Lernen. Außerdem stehen ethische und datenschutzrechtliche Implikationen von KI-Anwendungen im Fokus.\r\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\r\nVerwende ausschließlich folgende Abstufungen:\r\n0 = keine Relevanz / trifft gar nicht zu\r\n0,3 = geringe Relevanz / teilweise Abdeckung\r\n0,7 = deutlicher Schwerpunkt\r\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\r\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\r\nKeine anderen Werte angeben.', '0.7');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_list`
--

CREATE TABLE `crawl_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `master_id` int(11) NOT NULL,
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `markup` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'alt (markup hat sich nicht geändert), neu (llm muss arbeiten)',
  `crawled_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_master`
--

CREATE TABLE `crawl_master` (
  `id` int(11) NOT NULL,
  `URL` text NOT NULL,
  `Verzeichnis` varchar(256) NOT NULL,
  `Paginierung` varchar(256) NOT NULL,
  `PaginierungsEigenschaft` varchar(256) NOT NULL,
  `PaginierungsStopp` varchar(256) NOT NULL,
  `Detailseite` varchar(256) NOT NULL,
  `Ebene` varchar(256) NOT NULL,
  `FieldsPrompt` text NOT NULL,
  `FieldsExample` text NOT NULL,
  `PrePrompt` text NOT NULL,
  `PostPrompt` text NOT NULL,
  `Headerfilter` text NOT NULL,
  `Footerfilter` text NOT NULL,
  `Seite` varchar(256) NOT NULL,
  `Kommentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offers`
--

CREATE TABLE `offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `crawl_list_id` bigint(20) UNSIGNED NOT NULL,
  `url` text NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `level` double DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offer_competencies`
--

CREATE TABLE `offer_competencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `offer_id` bigint(20) UNSIGNED NOT NULL,
  `competency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `score` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offer_dates`
--

CREATE TABLE `offer_dates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `offer_id` bigint(20) UNSIGNED NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `price_num` float DEFAULT NULL,
  `duration` text DEFAULT NULL,
  `start` text DEFAULT NULL,
  `anytime` tinyint(1) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `zip` text DEFAULT NULL,
  `place` text DEFAULT NULL,
  `is_online` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `prompt`
--

CREATE TABLE `prompt` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(10000) NOT NULL,
  `part` varchar(256) NOT NULL,
  `data` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `prompt`
--

INSERT INTO `prompt` (`id`, `identifier`, `part`, `data`, `created_at`, `updated_at`) VALUES
(1, 'preprompt', '', 'Bitte extrahiere folgende Information des Seminars / Kurses als JSON-Objekt mit folgenden Feldern:', NULL, NULL),
(2, 'title', 'field', 'Titel des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(3, 'description', '', 'Kurzbeschreibung des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(4, 'provider', '', 'Name des Seminaranbieters. Leerer String wenn keine Angabe gefunden wird.', NULL, NULL),
(10, 'level', '', 'Geschätzte Schwierigkeit / Einstiegshöhe des Seminars, Kurs oder der Veranstaltung. Grundkurse werden leichter eingeschätzt als Kurse für die Erfahrung vorausgesetzt wird.\nEin Anfängerkurs, Einstiegskurs oder eine Einführung hätte den Wert 0.\nEin Kurs für Fortgeschrittene hätte einen Wert von 0,5.\nEin Kurs für Experten hätte den Wert 1.\nVerwende ausschließlich diese drei Kategorien:\nEinsteigerkurs: 0\nFür Fortgeschrittene: 0,5\nFür Experten: 1', NULL, NULL),
(11, 'postprompt', '', 'Weil deine Antwort als JSON weiterverarbeitet werden soll, ist es wichtig, dass nur das JSON Objekt ausgegeben wird ohne erklärende Texte oder Hinweise.\nWenn du auf der gegebenen Seite kein Seminar / Kurs findest, oder wenn es sich um eine Übersichtsseite mit mehreren Kursen handelt dann antworte mit FALSE.', NULL, NULL);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indizes für die Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD PRIMARY KEY (`category_slug`,`competency_type_slug`),
  ADD KEY `idx_competency_type_slug` (`competency_type_slug`);

--
-- Indizes für die Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_competency_types_slug` (`slug`);

--
-- Indizes für die Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `crawl_list_url_unique` (`url`) USING HASH;

--
-- Indizes für die Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offers_webtexts_id_foreign` (`crawl_list_id`) USING BTREE;

--
-- Indizes für die Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offer_competencies_offer_id_foreign` (`offer_id`);

--
-- Indizes für die Tabelle `offer_dates`
--
ALTER TABLE `offer_dates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offer_dates_offer_id_foreign` (`offer_id`);

--
-- Indizes für die Tabelle `prompt`
--
ALTER TABLE `prompt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `prompt_key` (`identifier`) USING HASH;

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT für Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offers`
--
ALTER TABLE `offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offer_dates`
--
ALTER TABLE `offer_dates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `prompt`
--
ALTER TABLE `prompt`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD CONSTRAINT `fk_cct_category` FOREIGN KEY (`category_slug`) REFERENCES `categories` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cct_competency_type` FOREIGN KEY (`competency_type_slug`) REFERENCES `competency_types` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
