-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 11. Mai 2026 um 02:03
-- Server-Version: 10.11.14-MariaDB-0+deb12u2
-- PHP-Version: 8.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `THKoeln_live`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`) VALUES
(1, 'Verwaltung', 'Verwaltung'),
(2, 'Lehrende', 'Lehrende'),
(3, 'Studierende', 'Studierende'),
(4, 'Default', 'Default');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories_crawl_master`
--

CREATE TABLE `categories_crawl_master` (
  `categories_slug` varchar(255) NOT NULL,
  `crawl_master_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `category_competency_type`
--

CREATE TABLE `category_competency_type` (
  `category_slug` varchar(255) NOT NULL,
  `competency_type_slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `competency_types`
--

CREATE TABLE `competency_types` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'float',
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `example` text NOT NULL,
  `standard` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_list`
--

CREATE TABLE `crawl_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `master_id` int(11) NOT NULL,
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `markup` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'alt (markup hat sich nicht geändert), neu (llm muss arbeiten)',
  `crawled_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_master`
--

CREATE TABLE `crawl_master` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `URL` text NOT NULL,
  `Verzeichnis` varchar(256) NOT NULL,
  `Paginierung` varchar(256) NOT NULL,
  `PaginierungsEigenschaft` varchar(256) NOT NULL,
  `PaginierungsStopp` varchar(256) NOT NULL,
  `Detailseite` varchar(256) NOT NULL,
  `Ebene` varchar(256) NOT NULL,
  `FieldsPrompt` text NOT NULL,
  `FieldsExample` text NOT NULL,
  `PrePrompt` text NOT NULL,
  `PostPrompt` text NOT NULL,
  `Headerfilter` text NOT NULL,
  `Footerfilter` text NOT NULL,
  `Seite` varchar(256) NOT NULL,
  `Kommentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_master_competency_types`
--

CREATE TABLE `crawl_master_competency_types` (
  `master_id` int(11) NOT NULL,
  `competency_slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offers`
--

CREATE TABLE `offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `crawl_list_id` bigint(20) UNSIGNED NOT NULL,
  `url` text NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `level` double DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offer_competencies`
--

CREATE TABLE `offer_competencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `offer_id` bigint(20) UNSIGNED NOT NULL,
  `competency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `score` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `prompt`
--

CREATE TABLE `prompt` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(10000) NOT NULL,
  `part` varchar(256) NOT NULL,
  `data` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `prompt`
--

INSERT INTO `prompt` (`id`, `identifier`, `part`, `data`, `created_at`, `updated_at`) VALUES
(1, 'preprompt', '', 'Bitte extrahiere folgende Information des Seminars / Kurses als JSON-Objekt mit folgenden Feldern:', NULL, NULL),
(2, 'title', 'field', 'Titel des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(3, 'description', '', 'Kurzbeschreibung des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(4, 'provider', '', 'Name des Seminaranbieters. Leerer String wenn keine Angabe gefunden wird.', NULL, NULL),
(10, 'level', '', 'Geschätzte Schwierigkeit / Einstiegshöhe des Seminars, Kurs oder der Veranstaltung. Grundkurse werden leichter eingeschätzt als Kurse für die Erfahrung vorausgesetzt wird. Verwende ausschließlich die Werte 0; 0,5 oder 1', NULL, NULL),
(11, 'postprompt', '', 'Weil deine Antwort als JSON weiterverarbeitet werden soll, ist es wichtig, dass nur das JSON Objekt ausgegeben wird ohne erklärende Texte oder Hinweise.\nWenn du auf der gegebenen Seite kein Seminar / Kurs findest, oder wenn es sich um eine Übersichtsseite mit mehreren Kursen handelt dann antworte mit FALSE.', NULL, NULL);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indizes für die Tabelle `categories_crawl_master`
--
ALTER TABLE `categories_crawl_master`
  ADD PRIMARY KEY (`categories_slug`,`crawl_master_id`),
  ADD KEY `fk_ccm_crawl` (`crawl_master_id`);

--
-- Indizes für die Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD PRIMARY KEY (`category_slug`,`competency_type_slug`),
  ADD KEY `idx_competency_type_slug` (`competency_type_slug`);

--
-- Indizes für die Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_competency_types_slug` (`slug`);

--
-- Indizes für die Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `crawl_list_url_unique` (`url`) USING HASH;

--
-- Indizes für die Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `crawl_master_competency_types`
--
ALTER TABLE `crawl_master_competency_types`
  ADD PRIMARY KEY (`master_id`,`competency_slug`),
  ADD KEY `idx_competency_slug` (`competency_slug`);

--
-- Indizes für die Tabelle `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offers_webtexts_id_foreign` (`crawl_list_id`) USING BTREE;

--
-- Indizes für die Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offer_competencies_offer_id_foreign` (`offer_id`);

--
-- Indizes für die Tabelle `prompt`
--
ALTER TABLE `prompt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `prompt_key` (`identifier`) USING HASH;

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offers`
--
ALTER TABLE `offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `prompt`
--
ALTER TABLE `prompt`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `categories_crawl_master`
--
ALTER TABLE `categories_crawl_master`
  ADD CONSTRAINT `fk_ccm_category` FOREIGN KEY (`categories_slug`) REFERENCES `categories` (`slug`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ccm_crawl` FOREIGN KEY (`crawl_master_id`) REFERENCES `crawl_master` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD CONSTRAINT `fk_cct_category` FOREIGN KEY (`category_slug`) REFERENCES `categories` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cct_competency_type` FOREIGN KEY (`competency_type_slug`) REFERENCES `competency_types` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `crawl_master_competency_types`
--
ALTER TABLE `crawl_master_competency_types`
  ADD CONSTRAINT `fk_cmct_competency` FOREIGN KEY (`competency_slug`) REFERENCES `competency_types` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cmct_master` FOREIGN KEY (`master_id`) REFERENCES `crawl_master` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
